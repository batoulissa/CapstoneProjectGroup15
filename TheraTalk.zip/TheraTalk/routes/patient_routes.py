import os
from flask import Blueprint, request, jsonify
from models import db, Patient
from hashlib import sha256

patient_routes = Blueprint('patient_routes', __name__)

# Hash Password
def hash_password(password):
    return sha256(password.encode()).hexdigest()

# Patient Registration
@patient_routes.route('/register', methods=['POST'])
def register_patient():
    data = request.form

    # Get patient details
    name = data.get('name')
    age = data.get('age')
    gender = data.get('gender')
    medical_history = data.get('medical_history')
    theraphy_need = data.get('theraphy_need')
    languages = data.get('languages')
    availability = data.get('availability')
    password = data.get('password')
    # Handle file upload (proof of education)
    file = request.files.get('patient_id_card')
    
    if not file:
        return jsonify({"message": "Identification is required!"}), 400

    # Check if the file is a PDF
    if not file.filename.endswith('.pdf'):
        return jsonify({"message": "Invalid file type. Please upload a PDF file."}), 400

    # Define the upload path and save the file
    file_path_patient = os.path.join('uploads', file.filename)  # Save the file
    file.save(file_path_patient)

    hashed_password = hash_password(password)

    # Create new patient
    new_patient = Patient(
        name=name,
        age=age,
        gender=gender,
        medical_history=medical_history,
        therapy_need=theraphy_need,
        languages=languages,
        availability=availability,
        password=hashed_password,
        status="pending",
        patient_id_card=file_path_patient
    )

    # Add to DB
    db.session.add(new_patient)
    db.session.commit()

    return jsonify({"message": "Patient registered successfully!"}), 201

# Patient Login
@patient_routes.route('/login', methods=['POST'])
def login_patient():
    data = request.get_json()

    name = data.get('name')
    password = data.get('password')

    hashed_password = hash_password(password)

    patient = Patient.query.filter_by(name=name).first()

    if patient and patient.password == hashed_password:
        return jsonify({"message": "Login successful!"}), 200
    return jsonify({"message": "Invalid credentials!"}), 401
